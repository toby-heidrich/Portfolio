#========================================
# This python script is part of CDS 303 - Project Team 1's execution of the CRISP-DM method.
# Authors: Tobias Heidrich, Jubilee Gebru, Samantha Gorman, Elias Gahche, and Jenna Jensen
#========================================
# Library imports

import warnings
warnings.filterwarnings("ignore")

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.neural_network import MLPRegressor
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GridSearchCV
from sklearn.inspection import permutation_importance
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import RobustScaler
from sklearn.preprocessing import PowerTransformer

#========================================
# Read in data

data = pd.read_excel('CustomSP_Data.xlsx', sheet_name='Data3', header=0)
data = data.iloc[50:].reset_index(drop=True) #added to avoid NAN values in mlp.fit                   !!!set to 10 if using lag variables, or 50 if using apple emas!!!
data = data.drop(data.index[-1]) #Drop last row to avoid NaN

#========================================
# Prepare features and targets
#feature_names = ['NASDAQ','BETA-AAPL','Gold','SP500-EMA10','lag1','lag2','lag3','Volume','SP500','EPS','OIL']
#X = data[['NASDAQ','BETA-AAPL','Gold','SP500-EMA10','lag1','lag2','lag3','Volume','SP500','EPS','OIL']]

feature_names = ['NASDAQ','BETA-AAPL','Gold','SP500-EMA10','AAPL-EMA10','AAPL-EMA20','AAPL-EMA50','Volume','SP500','EPS','OIL']
X = data[['NASDAQ','BETA-AAPL','Gold','SP500-EMA10','AAPL-EMA10','AAPL-EMA20','AAPL-EMA50','Volume','SP500','EPS','OIL']]
y = data['AAPL']

#========================================
# Run time series split

tscv = TimeSeriesSplit(n_splits=4)

#========================================
# Initialize scalers

scaler_x = StandardScaler()
scaler_y = StandardScaler()
#========================================
# Run Model

for i, (train_index, test_index) in enumerate(tscv.split(X)):
    X_train, X_test = X.iloc[train_index], X.iloc[test_index]
    y_train, y_test = y.iloc[train_index], y.iloc[test_index]
    
    # Scale X (features)
    X_train_scaled = scaler_x.fit_transform(X_train)  # Fit and transform X_train
    X_test_scaled = scaler_x.transform(X_test)        # Transform X_test only

    # Scale y (target)
    y_train_scaled = scaler_y.fit_transform(y_train.values.reshape(-1, 1)).ravel()  # Fit and transform y_train
    y_test_scaled = scaler_y.transform(y_test.values.reshape(-1, 1)).ravel()        # Transform y_test only

    # Initialize and train the MLP model
    #mlp = MLPRegressor(hidden_layer_sizes=(50,50), max_iter=1000, activation='identity', alpha=0.001, learning_rate='constant', solver='lbfgs', random_state=42) #best when using EMAs
    mlp = MLPRegressor(hidden_layer_sizes=(50,), max_iter=1000, activation='identity', alpha=0.01, learning_rate='constant', solver='lbfgs', random_state=42) #best when using lag vars
    mlp.fit(X_train_scaled, y_train_scaled)

    # extract weights from input layer to the first hidden layer
    input_to_hidden_weights = mlp.coefs_[0]

    # Calculate feature importance as the sum of absolute weights for each feature
    feature_importance = np.sum(np.abs(input_to_hidden_weights), axis=1)

    # Permutation feature importance
    perm_importance = permutation_importance(mlp, X_test_scaled, y_test_scaled, n_repeats=10, random_state=42)

     # Predict and evaluate
    y_train_pred_scaled = mlp.predict(X_train_scaled)  # Predicted values for the train set
    y_train_pred = scaler_y.inverse_transform(y_train_pred_scaled.reshape(-1, 1)).ravel()  # Inverse transform for train

    y_test_pred_scaled = mlp.predict(X_test_scaled)  # Predicted values for the test set
    y_test_pred = scaler_y.inverse_transform(y_test_pred_scaled.reshape(-1, 1)).ravel()  # Inverse transform for test

    # Calculate R-squared for both train and test
    r2_train = r2_score(y_train, y_train_pred)  # R-squared for training set
    r2_test = r2_score(y_test, y_test_pred)    # R-squared for test set

    # Print R-squared values
    print(f"Split {i+1}:")
    print(f"R-squared (Train): {r2_train:.4f}")
    print(f"R-squared (Test): {r2_test:.4f}")
    rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
    
    # Display feature importance
    print(f"Split {i+1}:")

    for j, feature in enumerate(feature_names):
        print(f"Feature: {feature}, Weights: {feature_importance[j]:.4f}")

    # Display permutation feature importance
    for k, feature in enumerate(feature_names):
        print(f"Feature: {feature}, Permutation Importance: {perm_importance.importances_mean[k]:.4f}")

    # print info on fold and rmse
    print(f"Train period: {train_index[0]} to {train_index[-1]}")
    print(f"Test period: {test_index[0]} to {test_index[-1]}")
    print(f"RMSE: {rmse}\n")

#========================================
# Assuming y_test contains the actual values and y_pred contains the predicted values

plt.figure(figsize=(10, 6))

# Plot actual vs predicted values
plt.scatter(y_test, y_test_pred, color='blue', label='Predicted vs Actual')

# Plotting a line y=x for reference (perfect prediction line)
plt.plot([min(y_test), max(y_test)], [min(y_test), max(y_test)], color='red', linestyle='--', label='Perfect prediction line')

# Adding labels and title
plt.xlabel('Actual Values')
plt.ylabel('Predicted Values')
plt.title('Predicted vs Actual Values')
plt.legend()

# Show plot
plt.show()
#=======================================